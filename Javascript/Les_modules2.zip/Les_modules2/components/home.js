import {getMovieCard, getMovieDetails, getPopularMovies, IMAGE_URL} from "../services/movie.js";

document.addEventListener('DOMContentLoaded', async () => {
    // Initialisation des éléments DOM
    const contentElement = document.querySelector('#content')
    const previousBtnElement = document.querySelector('#previous-btn')
    const nextBtnElement = document.querySelector('#next-btn')
    const spinnerElement = document.querySelector('#spinner')
    const modalElement = document.querySelector('#modal')
    const modal = new bootstrap.Modal(modalElement)

    let currentPage = 1

    // Fonction pour mettre à jour le contenu principal avec les films populaires
    const setHomeBody = (results) => {
        const homeBody = []

        for (let i = 0; i < results.length; i++) {
            homeBody.push(getMovieCard(results[i]))
        }

        contentElement.innerHTML = homeBody.join('')
        const moreInfoBtn = document.querySelectorAll('.more-info-btn')

        // Ajout des événements sur les boutons "plus d'infos"
        for (let i = 0; i < moreInfoBtn.length; i++) {
            moreInfoBtn[i].addEventListener('click', async (e) => {
                e.preventDefault()
                const movieId = e.target.getAttribute('data-id')
                const movieDetails = await getMovieDetails(movieId)
                modalElement.querySelector('.modal-title').innerHTML = movieDetails.title

                const genres = movieDetails.genres.map(genre => `<span class="badge text-bg-info ms-1 text-white">${genre.name}</span>`)
                modalElement.querySelector('.modal-body').innerHTML = `
                <div> <img src="${IMAGE_URL}${movieDetails.backdrop_path}" class="card-img-top"/></div>
                <div>"Durée (min): ${movieDetails.runtime}"</div>

                ${genres.join('')}
                <div>"${movieDetails.overview}"</div>

                `

                modal.show()
            })
        }
    }

    // Fonction pour naviguer vers la page précédente
    previousBtnElement.addEventListener('click', async () => {
        if (currentPage > 1) {
            currentPage--
            spinnerElement.classList.remove('d-none')
            const {results} = await getPopularMovies(currentPage)
            setHomeBody(results)
            spinnerElement.classList.add('d-none')
        } else {
            alert('Vous avez atteint la première page')
        }
    })

    // Fonction pour naviguer vers la page suivante
    nextBtnElement.addEventListener('click', async () => {
        currentPage++
        spinnerElement.classList.remove('d-none')
        const {results} = await getPopularMovies(currentPage)
        setHomeBody(results)
        spinnerElement.classList.add('d-none')
    })

    // Chargement initial des films populaires
    spinnerElement.classList.remove('d-none')
    const {results} = await getPopularMovies()
    setHomeBody(results)
    spinnerElement.classList.add('d-none')

})
