import { getMovieCard,getPopularMovies } from "../services/movie.js";

document.addEventListener("DOMContentLoaded", async() => {
  const contentElement = document.querySelector("#content")
  const {results} =  await getPopularMovies()

  const homebody = []

  for (let i = 0; i < results.length; i++) {
  homebody.push(getMovieCard(results[i]))
  }

  contentElement.innerHTML = homebody.join('')


});
